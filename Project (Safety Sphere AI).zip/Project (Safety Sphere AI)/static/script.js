document.addEventListener('DOMContentLoaded', function() {
    const stressLevelInput = document.getElementById('stressLevel');
    const clearButton = document.getElementById('clearButton');
    const submitButton = document.getElementById('submitButton');
    const heartRate = document.getElementById('heartRate');
    const skinTemp = document.getElementById('skinTemp');
    const eda = document.getElementById('eda');
    const respirationRate = document.getElementById('respirationRate');
    const prediction = document.getElementById('prediction');
    const predictionIndicator = document.getElementById('prediction-indicator');

    clearButton.addEventListener('click', function() {
        stressLevelInput.value = 50;
        heartRate.textContent = '123';
        skinTemp.textContent = '37.33';
        eda.textContent = '2.47';
        respirationRate.textContent = '14';
        prediction.textContent = 'No Harassment Detected.';
        predictionIndicator.classList.remove('indicator-on');
        predictionIndicator.classList.add('indicator-off');
    });

    submitButton.addEventListener('click', function() {
        const stressValue = stressLevelInput.value;

        fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ stress_level: stressValue }),
        })
        .then(response => response.json())
        .then(data => {
            heartRate.textContent = data.heart_rate;
            skinTemp.textContent = data.skin_temp;
            eda.textContent = data.eda;
            respirationRate.textContent = data.respiration_rate;
            prediction.textContent = data.prediction;

            if (data.prediction.includes("Harassment Likely Detected")) {
                predictionIndicator.classList.remove('indicator-off');
                predictionIndicator.classList.add('indicator-on');
            } else {
                predictionIndicator.classList.remove('indicator-on');
                predictionIndicator.classList.add('indicator-off');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            prediction.textContent = 'Error occurred.';
            predictionIndicator.classList.remove('indicator-on');
            predictionIndicator.classList.add('indicator-off');
        });
    });
});
